const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8082 });

wss.on('listening', () => {
    console.log('WebSocket server is running on port 8082');
});

wss.on('connection', (ws) => {
    console.log(ws.id)
    console.log('A Client Connected to server');

    ws.on('message', (data) => {
        const message = JSON.parse(data);
        console.log('Received message from client:', message);

        // Check if the message indicates a 'LuckyGift' event
        if (message.event === 'LuckyGift') {
            console.log('Received LuckyGift event from client');

            // Check if the WebSocket connection is in the OPEN state
            if (ws.readyState === WebSocket.OPEN) {
                // Emitting a 'LuckyGiftResponse' event back to the client
                const response = JSON.stringify({ event: 'LuckyGiftResponse', data: message.data });
                // Attempt to send the response
                ws.send(response, (error) => {
                    if (error) {
                        console.error('Error occurred while sending response:', error);
                    } else {
                        console.log('LuckyGiftResponse sent successfully');
                    }
                });
            } else {
                console.log('WebSocket connection is not in the OPEN state, cannot send response.');
            }
        }
    });

    ws.on('close', () => {
        console.log('Client Disconnected');
    });
});
