const WebSocket = require('ws');
const { v4: uuidv4 } = require('uuid');

const wss = new WebSocket.Server({ port: 8082 });

const clients = new Map(); // Map to store WebSocket connections with user IDs

wss.on('listening', () => {
    console.log('WebSocket server is running on port 8082');
});

wss.on('connection', (ws) => {
    const userId = uuidv4(); // Generate a unique user ID for each connection
    clients.set(userId, ws); // Store the WebSocket connection with the user ID

    console.log(`User connected with ID: ${userId}`);

    ws.on('message', (data) => {
        const message = JSON.parse(data);
        const { recipientId, content } = message;

        // Check if the recipient exists in the map and if they're connected
        if (clients.has(recipientId) && clients.get(recipientId).readyState === WebSocket.OPEN) {
            const recipientSocket = clients.get(recipientId);
            const messageToSend = JSON.stringify({ senderId: userId, content });

            recipientSocket.send(messageToSend);
        } else {
            // Handle cases where the recipient is not found or not connected
            console.log(`Recipient with ID ${recipientId} not found or not connected`);
        }
    });

    ws.on('close', () => {
        clients.delete(userId); // Remove the WebSocket connection from the map upon disconnection
        console.log(`User disconnected with ID: ${userId}`);
    });
});
